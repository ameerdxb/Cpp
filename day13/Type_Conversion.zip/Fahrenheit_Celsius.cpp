﻿#include<iostream>
#include<math.h>
using namespace std;
#include<string>

//type to which it will be converted
class Celsius;//forward declaration

class Fahrenheit {
	double temp;
public:
	
	void display();
	operator Celsius();
	Fahrenheit(double t);

};
//class to be converted
class Celsius {
	float temp;
public:
	
	void display() {
		cout << temp << endl;
	}
	Celsius(float t=0.0)
	{
		temp = t;
	}
};

void Fahrenheit::display() {
	cout << temp << endl;
}
Fahrenheit::operator Celsius()
{
	double f = (temp - 32.0) * 5.0 / 9.0;
	return Celsius(f);
}
Fahrenheit::Fahrenheit(double t)
{
	temp = t;
}
int main() {
	
	Fahrenheit f(100);
	Celsius c;
	c = f;
	c.display();
	f.display();
	return 0;
}