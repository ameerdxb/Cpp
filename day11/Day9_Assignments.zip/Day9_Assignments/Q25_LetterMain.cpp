#include <iostream>
#include <cctype>
#include "Letter.h"
using namespace std;

int main()
{
	CInput oC1;
	oC1.getLetter();

	return 0;
}