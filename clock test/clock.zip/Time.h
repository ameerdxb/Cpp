#pragma once
#include<iostream>
using namespace std;

class CTime
{
	// Declaring member functions
public:
	// Argumented constructor
	CTime(int nHour=0, int nMinute=0, int nSecond=0);

	// Copy constructor
	CTime(const CTime&);

	// Increment function
	void Increment();

	// Get function
	void Get(int&, int&, int&)const;

private:
	// Declaring member variables
	 int m_nHour;
	 int m_nMinute;
	 int m_nSecond;

};

