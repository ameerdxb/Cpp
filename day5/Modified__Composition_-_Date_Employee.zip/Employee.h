 // Fig. 10.12: Employee.h
  // Employee class definition.
  // Member functions defined in Employee.cpp.
  #ifndef EMPLOYEE_H
  #define EMPLOYEE_H

  #include "Date.h" // include Date class definition

  class Employee
  {
  public:
     Employee( const char * , const char * ,
        const Date& , const Date&  );
     void print() const;
     ~Employee(); // provided to confirm destruction order
  private:
     char firstName[ 25 ];
     char lastName[ 25 ];
      Date birthDate; // composition: member object
     const Date hireDate; // composition: member object
  }; // end class Employee

  #endif


