#include <iostream>
using namespace std;

#include "Shape.h"
#include "Square.h"
#include "Traingle.h"

void  main()
{
	//Shape* s = new Shape();
	Square sq(10);
	Shape* s = &sq;
	s->Area();
	s->Perimeter();

	Shape* s1 = new Triangle(3, 4);
	s1->Area();
	s1->Perimeter();



}